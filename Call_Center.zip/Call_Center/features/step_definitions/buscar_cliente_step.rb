Dado("que estou na tela de login do Call Center") do
	@atendimento = CallCenter.new
	@atendimento.load
end

Quando("realizar o login com usuário válido") do
	@atendimento.login.submit
end

Então("o login é realizado com sucesso") do
	expect(@atendimento).to have_content("Olá, #{USUARIO_ACESSO[:login_admin]}")
	@atendimento.menu_cliente_demanda.iniciar_atendimento
	@atendimento.demanda.selecionar_perfil
end

Então("exibido o número de protocolo do atendimento") do
	expect(@atendimento.demanda.numero_protocolo) != nil 
	@atendimento.menu_cliente_demanda.consultar_cliente
	@atendimento.demanda.situacao_cliente
end

Dado("que estou logado no Call Center") do
	steps %Q{
		Dado que estou na tela de login do Call Center
		Quando realizar o login com usuário válido
		Então o login é realizado com sucesso
		E exibido o número de protocolo do atendimento
	}
end
