Quando("filtrar por taxa de {string}") do |taxa|
  @atendimento.menu_cliente_demanda.selecionar_demanda(DEMANDA[:contestar],SUBDEMANDA[:taxa])
  @atendimento.demanda.validar_dados_seguranca
  @atendimento.contestar_taxa.filtrar_resultado(taxa)  
end

Quando("contestar {string} taxa por motivo {string}") do |quantidade, motivo|
  @atendimento.contestar_taxa.selecionar_filtro_taxa(motivo)
  @atendimento.contestar_taxa.selecionar_transacao(quantidade)
end

Quando("crédito para {string}") do |tipo_credito|
  #validar as taxas contestadas
  #expect().to_have()
  @atendimento.contestar_taxa.creditar_taxa(tipo_credito)
end

Então("verifico os dados da contestação e o número de ocorrência") do
  
end
