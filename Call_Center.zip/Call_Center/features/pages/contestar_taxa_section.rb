require 'site_prism'

class ContestarTaxa < SitePrism::Section

  element :select_tipo_taxa,          "#actionForm_tipoTaxa"
  element :input_fatura,              "#actionForm_faturaPesquisa"
  element :input_data_inicial,        "#actionForm_dataInicio"
  element :select_tipo_identificacao, "#actionForm_tipoBusca"
  element :input_tipo_identificacao,  "#actionForm_valorPesquisa"
  element :input_data_final,          "#actionForm_dataFim"
  element :button_buscar,             "[value='incluir']"

  #Resultado Pesquisa
  element :select_motivo,             "#actionForm_motivo"
  element :radio_parcial,             "#[value='sim']"
  element :radio_nao_parcial,         "#[value='nao']"
  element :input_valor_alegado,       "#actionForm_valorAlegado"
  element :button_incluir,            "[value='incluir']"
  element :button_avancar,            "[value='avançar']"
  
  #Taxas Contestadas
  element :radio_proxima_fatura,      "#fatura"
  element :radio_deposito_cc,         "#conta_corrente"
  element :radio_ordem_pagamento,     "#ordem_pagamento"
  element :select_banco,              "#select"
  element :input_agencia,             ".m_numero"
  element :input_conta, :xpath        "//input[contains(@name, 'contaMascarada')]"
  element :input_digito,              ".m_digitoconta"

  def filtrar_resultado(tipo_taxa)
    select(tipo_taxa, from: "actionForm_tipoTaxa").select_option
    filtrar_data
    button_buscar.click
  end

  def filtrar_data
    data_inicio = Date.today - 90
    data_fim    = Date.today
    input_data_inicial.set "#{data_inicio.strftime('%d %m %Y').to_s}"
    input_data_final.click
    input_data_final.set      "#{data_fim.strftime('%d %m %Y').to_s}"
  end

  def selecionar_filtro_taxa(motivo)
    select(motivo, from: "actionForm_motivo").select_option
    input_valor_alegado.set "3,33"
  end

  def selecionar_transacao(quantidade)
      if quantidade == "uma"
        first("[rel='NC']").check
      else
        nc = page.all("[rel='NC']")
        nc.each { |elemento| elemento.check }
      end
    button_incluir.click
    button_avancar.click
  end

  def creditar_taxa(tipo_credito)
    case tipo_credito
    when "Próxima Fatura"
      radio_proxima_fatura.choose
    when "Depósito em Conta Corrente"
      radio_deposito_cc.choose
      conta_terceiro
    else
      radio_ordem_pagamento.choose
    end
    button_avancar.click
  end

  def conta_terceiro
    #Verificar se os campos abaixo estão sem preenchimento
=begin
  select_banco
  input_agencia
  input_conta
  input_digito
=end
    DADOS_CONTA[:banco], DADOS_CONTA[:agencia], DADOS_CONTA[:cc], DADOS_CONTA[:digito]
  end
end