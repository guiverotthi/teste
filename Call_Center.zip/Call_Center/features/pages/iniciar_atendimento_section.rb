require 'site_prism'

class IniciarAtendimento < SitePrism::Section

  #Iniciar Atendimento
  element :button_iniciar_atendimento, :xpath,       "//img[contains(@src, 'bt-iniciar-atendimento.gif')]"

  #Perfil
  element :radio_perfil_sac,                         "[value='SAC']"
  element :radio_perfil_customer,                    "[value='Customer']"
  element :radio_perfil_retencao,                    "[value='Retenção']"
  element :radio_perfil_b2b,                         "[value='B2B']"
  element :radio_perfil_vp,                          "[value='Vale Pedagio']"
  element :radio_perfil_operador_inteiro,            "[value='Operador Interno']"
  element :radio_perfil_administrador,               "[value='Administrador']"
  element :button_confirmar_perfil,                  ".botao-arredondado"

  def iniciar_atendimento
    button_iniciar_atendimento.click
  end

  def selecionar_perfil
    radio_perfil_administrador.click
    button_confirmar_perfil.click
  end

  #Confirmação dos Dados
  element :text_numero_protocolo, :xpath,            "//div[@class='body_portlet']/table/tbody/tr/td[2]/span"
  element :button_avancar_protocolo,                 ".botao-arredondado"

  def numero_protocolo
  #binding.pry
    text_numero_protocolo.text.to_i
    button_avancar_protocolo.click
  end

  #Busca Cliente
  element :input_consulta_cliente,                   "#actionForm_valor"
  element :button_consulta_cliente, :xpath,          "//input[contains(@src, 'ok.gif')]"

  #Confirmação dos Dados / Situação do Cliente
  element :button_avancar,                           "[value='avançar']"
  element :button_avancar_confirmacao_dados, :xpath, "//body//input[2]"
  
  def consultar_cliente
    select(TIPO_CONSULTA[:codigo],             from: "actionForm_filtros").select_option
    input_consulta_cliente.set CLIENTE[:pf_pos_adimplente]
    button_consulta_cliente.click
    button_avancar_confirmacao_dados.click
  end

  #Verifica se cliente é adimplente
  def situacao_cliente
    if page.has_content?("INADIMPLENTE") 
      button_avancar
      puts "Cliente Inadimplente"
    else
      puts "Cliente Adimplente"
    end 
  end

  #Selecionar Demanda
  def selecionar_demanda(demanda,subdemanda)
    select(demanda,                            from: "selectPrimeiroNivel").select_option
    select(subdemanda,                         from: "selectSegundoNivel").select_option
  end
  
  #Validação dos dados de segurança
  element :input_data_nascimento,                    "#actionForm_dataNascimento"
  element :input_rg,                                 "#rg"
  element :select_banco,                              "#banco"
  element :input_agencia,                            "#agencia"
  element :input_conta,                              "#conta"
  element :input_data_debito,                        "#actionForm_diaVencimento"
  element :button_pular,                             "[value='pular']"
  element :button_cancelar,                          "[value='cancelar']"
  element :input_inscricao_estadual,                 "#inscricaoEstadual"
  element :input_qtde_veiculos_ativos,               "#qtdVeiculosAtivos"
  element :select_bandeira,                          "#operadora"
  element :input_numero_cartao,                      "#numerocartao"
  element :select_data_validade,                     "#mes"
  element :input_valor_periodico,                    "#valorPeriodico"
  element :input_qtde_veiculos_ativos_financiados,   "#qtdVeiculosAtivosFinanc"

  #Esta tela sofrerá alteração e no momento não valida os dados. Será necessário aguardar a implementação 
  def validar_dados_seguranca
    # input_data_nascimento.set DADOS_SEGURANCA[:data_nascimento] if input_data_nascimento
    button_avancar.click
  end

end
