require_relative 'login_section'
require_relative 'iniciar_atendimento_section'
require_relative 'contestar_taxa_section'

class CallCenter < SitePrism::Page

  set_url URL["url_uat"]

  section :login, Login, "#Netui_Form_0"

  #Menu superior com o Busca Cliente, Escolha a Conta, Escolha a Demanda e Iniciar/Finalizar Atendimento
  section :menu_cliente_demanda, IniciarAtendimento, "#buscaClienteForm"

  #Telas contendo as demandas e Cérebro Virtual
  section :demanda, IniciarAtendimento, "#geral"

  section :contestar_taxa, ContestarTaxa, "#geral"

end

