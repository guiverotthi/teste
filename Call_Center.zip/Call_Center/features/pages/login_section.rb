require 'site_prism'

class Login < SitePrism::Section

  #Login
  element :input_usuario,  '#actionForm_login'
  element :input_senha,    '#actionForm_senha'
  element :button_avancar, '[value="Login"]'

  def submit
    input_usuario.set   USUARIO_ACESSO[:login_admin]
    input_senha.set     USUARIO_ACESSO[:senha_admin]
    button_avancar.click
  end
end
