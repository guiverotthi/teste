USUARIO_ACESSO =
{
	login_admin: 				 "operador-admin",
	senha_admin: 				 "operador-admin"
}

CLIENTE = 
{
	pf_pos_adimplente:   "4152852"
}

TIPO_CONSULTA =
{
	cpf:								 "Consultar por CPF",
	cnpj:								 "Consultar por CNPJ",
	codigo:							 "Consultar por Código",
	placa:							 "Consultar por Placa",
	protocolo:					 "Consultar por Protocolo",
	dispositivo:				 "Consultar por Sem Parar",
	cpf_nao_cliente:		 "CPF - Não é cliente",
	cnpj_nao_cliente:		 "CNPJ - Não é cliente",
	conta:							 "Consultar por Conta"
}

DEMANDA = 
{
	alterar: 						 "Alterar",
	confirmar: 				 	 "Confirmar",
	consultar: 				 	 "Consultar",
	contestar: 				 	 "Contestar",
	localizar: 				 	 "Localizar",
	reclamar: 				 	 "Reclamar",
	solicitar: 				 	 "Soliticar"
}

SUBDEMANDA =
{
	taxa: 							 "Taxa"
}

DADOS_SEGURANCA =
{
	data_nascimento:		 							"01/01/1960",
	rg:									 							"111111111",
	banco:							 							"001 - BANCO DO BRASIL S.A.",
	agencia:						 							"6844",
	conta_corrente:			 							"1294388",
	data_debito:				 							"5",
	inscricao_estadual:               "250400421",
	qtde_veiculos_ativos:             "1",
	bandeira:                         "VISA",
	numero_cartao:                    "3449",
	data_validade:                    "#mes",
	valor_periodico:                  "#valorPeriodico",
	qtde_veiculos_ativos_financiados: "#qtdVeiculosAtivosFinanc"
}

DADOS_CONTA = 
{
	banco: 							"Banco do Brasil"													
  agencia: 						"0663"
  cc: 								"191310"
  digito: 						"7"
}