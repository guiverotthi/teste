Quando("eu acesso a página de login") do
  @platcom_page = PlatCom.new
  @platcom_page.load
end

Quando("eu submeto usuário e senha") do
  @platcom_page.login.submit
  @platcom_page.wait_until_menu_platcom_visible

end

Entao("eu vejo a home") do
    #expect(@platcom_page.menu_platcom).to have_consultas_menu_item
end

Dado("que eu esteja logado") do
  steps %Q{
    Quando eu acesso a página de login
    Quando eu submeto usuário e senha
    Entao eu vejo a home
  }
end
