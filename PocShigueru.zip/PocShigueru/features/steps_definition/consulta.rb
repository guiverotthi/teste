Quando("quando eu pesquisar por numero de pedido") do
  @platcom_page.menu_platcom.consultar_pedidos
  @platcom_page.pesquisar_por_numero_pedido
end

Então("eu vejo os detalhes deste pedido") do
  @platcom_page.ver_detalhes_pedido
  expect(@platcom_page).to have_form_detalhes_pedido
end
