Quando("quando preencho a aba de Dados Iniciais") do
  @platcom_page.menu_platcom.cadastrar_pedido

  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.wait_until_menu_platcom_visible

  @platcom_page.dados_iniciais.set_ponto_de_venda
  @platcom_page.dados_iniciais.set_vendedor

  @platcom_page.dados_iniciais.input_cpf.click
  @platcom_page.dados_iniciais.input_cpf.set CPF.generate #Substituir pela GEM 'cpf_cnpj'

  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.dados_iniciais.button_avancar.click

  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.dados_do_cliente.wait_until_input_nome_visible

  expect(@platcom_page.dados_do_cliente).to have_input_nome
end

Quando("preencho a aba Dados do Cliente") do
  @platcom_page.dados_do_cliente.input_nome.set("Teste Poc Platcom")
  @platcom_page.dados_do_cliente.input_rg.set("425525123")
  @platcom_page.dados_do_cliente.input_data_nascimento.click
  @platcom_page.dados_do_cliente.input_data_nascimento.set("05/11/1986")
  @platcom_page.dados_do_cliente.combobox_sexo.click
  @platcom_page.combobox_sexo_items.click
  @platcom_page.dados_do_cliente.combobox_estado_civil.click
  @platcom_page.combobox_estado_civil_items.click
  @platcom_page.dados_do_cliente.combobox_tipo_endereco.click
  @platcom_page.combobox_tipo_endereco_items.click
  @platcom_page.dados_do_cliente.input_cep.click
  @platcom_page.dados_do_cliente.input_cep.set("06120280")
  @platcom_page.dados_do_cliente.input_numero.click
  @platcom_page.dados_do_cliente.input_numero.click.set(rand(999).to_s)
  @platcom_page.dados_do_cliente.input_complemento.set("Apto 13 Bl 15")
  @platcom_page.dados_do_cliente.button_adicionar_endereco.click
  #TODO adicionar validação no endereço que é carregado na table //*[@id="formCadastrarPedido:j_idt676_data"]/tr/td[1]
  @platcom_page.dados_do_cliente.combobox_tipo_contato_items.click
  @platcom_page.combobox_tipo_contato_proprio.click
  @platcom_page.dados_do_cliente.input_ddd.set(11)
  @platcom_page.dados_do_cliente.input_telefone_fixo.click
  @platcom_page.dados_do_cliente.input_telefone_fixo.set(36090783)
  @platcom_page.dados_do_cliente.input_ramal.set(12345)
  @platcom_page.dados_do_cliente.input_ddd_celular.set(11)
  @platcom_page.dados_do_cliente.input_celular.click
  @platcom_page.dados_do_cliente.input_celular.set(991563621)
  @platcom_page.dados_do_cliente.input_ddd_fax.set(11)
  @platcom_page.dados_do_cliente.input_fax.click
  @platcom_page.dados_do_cliente.input_fax.set(36910875)
  @platcom_page.dados_do_cliente.input_email.set("teste.poc@gmail.com")
  @platcom_page.dados_do_cliente.input_email_confirmacao.set("teste.poc@gmail.com")
  @platcom_page.dados_do_cliente.button_adicionar_contato.click
  #TODO adicionar validação no contato que é carregado na table
  @platcom_page.button_avancar.click
  #Dados do Pedido
  @platcom_page.dados_do_pedido.radiobutton_forma_de_pagamento_debito.click
  @platcom_page.dados_do_pedido.combobox_banco.click
  @platcom_page.combobox_banco_items.click
  @platcom_page.dados_do_pedido.input_numero_agencia.click
  sleep 0.5
  @platcom_page.dados_do_pedido.input_numero_agencia.set("9337")
  @platcom_page.input_numero_conta_corrente.click
  @platcom_page.input_numero_conta_corrente.set("10125")
  @platcom_page.input_digito_conta_corrente.set("8")
  @platcom_page.dados_do_pedido.combobox_dia_de_pagamento.click
  @platcom_page.combobox_dia_de_pagamento_items.click
  @platcom_page.dados_do_pedido.radiobutton_autoriza_nfe_sim.click
  @platcom_page.dados_do_pedido.radiobutton_envio_da_fatura_email.click
  @platcom_page.dados_do_pedido.combobox_tipo_veiculo.click
  @platcom_page.combobox_tipo_veiculo_items.click
  @platcom_page.dados_do_pedido.input_capacidade.click
  sleep 1
  @platcom_page.dados_do_pedido.combobox_marca_veiculo.click
  @platcom_page.wait_until_combobox_marca_veiculo_items_visible
  @platcom_page.combobox_marca_veiculo_items.click
  @platcom_page.dados_do_pedido.combobox_modelo_veiculo.click
  @platcom_page.combobox_modelo_veiculo_items.click
  @platcom_page.dados_do_pedido.combobox_ano_fabricacao.click
  @platcom_page.combobox_ano_fabricacao_items.click
  @platcom_page.dados_do_pedido.combobox_ano_modelo.click
  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.combobox_ano_modelo_items.click
  @platcom_page.dados_do_pedido.combobox_combustivel.click
  @platcom_page.combobox_combustivel_items.click
  @platcom_page.dados_do_pedido.combobox_cor.click
  @platcom_page.combobox_cor_items.click
  @platcom_page.dados_do_pedido.combobox_categoria_veiculo.click
  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.combobox_categoria_veiculo_items.click
  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.dados_do_pedido.input_placa_veiculo.click
  @platcom_page.dados_do_pedido.input_placa_veiculo.set("CER1555")
  @platcom_page.dados_do_pedido.combobox_oferta_comercial.click
  @platcom_page.dados_do_pedido.combobox_oferta_comercial.click
  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.combobox_oferta_comercial_items.click
  @platcom_page.wait_until_loading_icon_invisible
  sleep 2
  @platcom_page.dados_do_pedido.combobox_promocao.click
  @platcom_page.combobox_promocao_items.click
  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.dados_do_pedido.button_adicionar_veiculo.click
  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.dados_do_pedido.radiobutton_tipo_de_entrega.click
  @platcom_page.dados_do_pedido.input_observacao_pedido.set("Cliente Adesao - PF - Cadastro Automatico")
  @platcom_page.dados_do_pedido.button_avancar_resumo_do_pedido.click
  @platcom_page.wait_until_loading_icon_invisible
  @platcom_page.dados_do_pedido.button_enviar_para_analise.click
end


