require "capybara"
require "capybara/cucumber"
require "rspec"
require "selenium-webdriver"
require "site_prism"
require "yaml"
require "pry"
require_relative "cpf.rb"

DATA = YAML.load_file "./features/dataset/dataset.yml"

Capybara.register_driver :selenium do |app|
  options = Selenium::WebDriver::Chrome::Options.new(args: ['--headless'])
  Capybara::Selenium::Driver.new(app, :browser => :chrome, options: options)
end

Capybara.default_driver = :selenium

Capybara.configure do |config|
  config.default_max_wait_time = 11
end
