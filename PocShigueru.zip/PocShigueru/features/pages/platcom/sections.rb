require "site_prism"

class MenuPlatcom < SitePrism::Section
  element :consultas_menu_item, "[id='j_idt14']"   #j_idt17\3a j_idt20 > ul > li.ui-widget.ui-menuitem.ui-corner-all.ui-menu-parent.ui-menuitem-active > a > span.ui-menuitem-text
  element :menu_operacoes, :xpath, "//span[contains(text(), 'Operações')]"
  element :menu_item_cadastrar_pedido, :xpath, "//span[contains(text(), 'Cadastrar Pedido')]"
  element :menu_consultas, :xpath, "//span[contains(text(), 'Consultas')]"
  element :menu_item_consultar_pedidos, :xpath, "//span[contains(text(), 'Consultar Pedidos')]"


  def cadastrar_pedido
    menu_operacoes.hover
    wait_until_menu_item_cadastrar_pedido_visible
    menu_item_cadastrar_pedido.click
  end

  def consultar_pedidos
    menu_consultas.hover
    wait_until_menu_item_consultar_pedidos_visible
    menu_item_consultar_pedidos.click
  end

end

class DadosIniciais < SitePrism::Section
  element :input_id_ponto_venda, :xpath, '//input[contains(@class, "ui-inputfield ui-inputmask ui-widget ui-state-default ui-corner-all")]'
  element :campo_vendendor, :xpath, '//label[contains(@class, "ui-selectonemenu-label ui-inputfield ui-corner-all")]'
  element :combobox_vendedor, "[id='formCadastrarPedido:vendedor_label']"
  #  element :combobox_vendedor_items, "[id='formCadastrarPedido:vendedor_items']" Movido para a page platcom.
  element :input_cpf, "[id='formCadastrarPedido:cpfCnpj']"
  element :button_avancar, "[id='formCadastrarPedido:j_idt338']"

  def set_vendedor
    PlatCom.new.set_vendedor
  end

  def set_ponto_de_venda
    #pv = "1046"
    input_id_ponto_venda.click
    input_id_ponto_venda.set("1046\n")
    #input_id_ponto_venda.set("\n")
  end

end

class DadosCliente < SitePrism::Section
  element :input_nome, "[id='formCadastrarPedido:nome']"
  element :input_rg, "[id='formCadastrarPedido:documentoRG']"
  element :input_data_nascimento, :id, 'formCadastrarPedido:dataNascimento_input'
  element :combobox_sexo, "[id='formCadastrarPedido:sexo_label']"
  #element :combobox_sexo_items, "[id='formCadastrarPedido:sexo_1']" Movido para a page platcom.
  element :combobox_estado_civil, "[id='formCadastrarPedido:estadoCivil']"
  #element :combobox_estado_civil_items, "[id='formCadastrarPedido:estadoCivil_5']" Movido para a page platcom.
  element :combobox_tipo_endereco, "[id='formCadastrarPedido:j_idt620_label']"
  #element :combobox_tipo_endereco_items, "[id='formCadastrarPedido:j_idt617_1']" Movido para a page platcom.
  element :input_cep, "[id='formCadastrarPedido:j_idt624']"
  element :input_numero, "[id='formCadastrarPedido:j_idt666']"
  element :input_complemento, "[id='formCadastrarPedido:j_idt664']"
  element :button_adicionar_endereco, "[id='formCadastrarPedido:adicionarEndereco']"
  element :combobox_tipo_contato_items,  "[id='formCadastrarPedido:j_idt707_label']"
  #element :combobox_tipo_contato_proprio, "[id='formCadastrarPedido:j_idt704_1']" Movido para a page platcom.
  element :input_ddd,  "[id='formCadastrarPedido:j_idt717']"
  element :input_telefone_fixo, "[id='formCadastrarPedido:numeroTelefone']"
  element :input_ramal, "[id='formCadastrarPedido:j_idt719']"
  element :input_ddd_celular, "[id='formCadastrarPedido:j_idt725']"
  element :input_celular, "[id='formCadastrarPedido:numeroCelular']"
  element :input_ddd_fax, "[id='formCadastrarPedido:j_idt733']"
  element :input_fax, "[id='formCadastrarPedido:numeroFax']"
  element :input_email, "[id='formCadastrarPedido:enderecoEmail']"
  element :input_email_confirmacao, "[id='formCadastrarPedido:enderecoEmailConfirmacao']"
  element :button_adicionar_contato, "[id='formCadastrarPedido:adicionarContato']"
  element :button_avancar, "[id='formCadastrarPedido:j_idt767']"

end

class DadosPedido < SitePrism::Section
  element :radiobutton_forma_de_pagamento_debito, :xpath, "//*[@id='formCadastrarPedido:radioFormaPagamento']/tbody/tr/td[1]/div/div[2]/span"
  element :combobox_banco, "[id='formCadastrarPedido:banco_label']"
  #element :combobox_banco_items, "[id='formCadastrarPedido:banco_12']"  Movido para a page platcom.
  element :input_numero_agencia, "[id='formCadastrarPedido:numeroAgencia']"
  #element :input_numero_conta_corrente, "[id='formCadastrarPedido:numeroConta']" Movido para a page platcom.
  #element :input_digito_conta_corrente, "[id='formCadastrarPedido:digitoConta']" Movido para a page platcom.
  element :combobox_dia_de_pagamento, "[id='formCadastrarPedido:diaPagamentoDebitoConta_label']"
  #element :combobox_dia_de_pagamento_items, "[id='formCadastrarPedido:diaPagamentoDebitoConta_2']" Movido para a page platcom.
  element :radiobutton_autoriza_nfe_sim, :xpath, "//*[@id='formCadastrarPedido:flagAutorizaNFE']/tbody/tr/td[2]/label"
  element :radiobutton_envio_da_fatura_email, :xpath, "//*[@id='formCadastrarPedido:tipoEnvioExtrato']/tbody/tr/td[3]/div/div[2]/span"
  element :combobox_tipo_veiculo, "[id='formCadastrarPedido:j_idt862_label']"
  element :combobox_marca_veiculo, "[id='formCadastrarPedido:comboMarcaVeiculo_label']"
  #element :combobox_marca_veiculo_items, "[id='formCadastrarPedido:comboMarcaVeiculo_8']" Movido para a page platcom.
  element :combobox_modelo_veiculo, "[id='formCadastrarPedido:comboModeloVeiculo_label']"
  #element :combobox_modelo_veiculo_items, "[id='formCadastrarPedido:comboModeloVeiculo_4']" Movido para a page platcom.
  element :combobox_ano_fabricacao, "[id='formCadastrarPedido:comboAnoFabricacao_label']"
  #element :combobox_ano_fabricacao_items, "[id='formCadastrarPedido:comboAnoFabricacao_22']" Movido para a page platcom.
  element :combobox_ano_modelo, "[id='formCadastrarPedido:comboAnoModelo_label']"
  #element :combobox_ano_modelo_items, "[id='formCadastrarPedido:comboAnoModelo_1']" Movido para a page platcom.
  element :combobox_combustivel, "[id='formCadastrarPedido:comboCombustivel_label']"
  #element :combobox_combustivel_items, "[id='formCadastrarPedido:comboCombustivel_2']" Movido para a page platcom.
  element :input_capacidade, "[id='formCadastrarPedido:capacidade']"
  element :combobox_cor, "[id='formCadastrarPedido:comboCor_label']"
  #element :combobox_cor_items, "[id='formCadastrarPedido:comboCor_2']" Movido para a page platcom.
  element :combobox_categoria_veiculo, "[id='formCadastrarPedido:comboCategoria_label']"
  #element :combobox_categoria_veiculo_items, "[id='formCadastrarPedido:comboCategoria_1']" Movido para a page platcom.
  element :input_placa_veiculo, "[id='formCadastrarPedido:j_idt897']"
  element :combobox_oferta_comercial, "[id='formCadastrarPedido:comboOfertaComercial_label']"
  #element :combobox_oferta_comercial_items, "[id='formCadastrarPedido:comboOfertaComercial_1']" Movido para a page platcom.
  element :combobox_promocao, "[id='formCadastrarPedido:comboPromocao_label']"
  #element :combobox_promocao_items, "[id='formCadastrarPedido:comboPromocao_1']" Movido para a page platcom.
  element :button_adicionar_veiculo, "[id='formCadastrarPedido:adicionarVeiculo']"
  element :radiobutton_tipo_de_entrega, :xpath, "//*[@id='formCadastrarPedido:j_idt1042']/tbody/tr/td[3]/div/div[2]/span"
  element :input_observacao_pedido, "[id='formCadastrarPedido:observacaoPedido']"
  element :button_avancar_resumo_do_pedido, "[id='formCadastrarPedido:buttonAvancar']"
  element :button_enviar_para_analise, "[id='formCadastrarPedido:j_idt1736']"
end

class Login < SitePrism::Section

  element :campo_usuario, :id, 'formLogin:userName'
  element :campo_senha,   :id, 'formLogin:password'
  element :btn_login,     :id, 'formLogin:j_idt18'

  def submit
    campo_usuario.set DATA["qa"]["user"]["name"]
    campo_senha.set   DATA["qa"]["user"]["password"]
    btn_login.click
  end

end
