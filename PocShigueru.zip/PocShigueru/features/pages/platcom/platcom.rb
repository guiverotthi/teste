require_relative "sections.rb"

class PlatCom < SitePrism::Page
  set_url DATA["qa"]["platcom_url"]

  section :login, Login, "#formLogin"
  section :menu_platcom, MenuPlatcom, '#j_idt17\3a j_idt20'
  section :dados_iniciais, DadosIniciais, "#formCadastrarPedido"
  section :dados_do_cliente,  DadosCliente, "[id='formCadastrarPedido:j_idt38']"
  section :dados_do_pedido, DadosPedido, "[id='formCadastrarPedido:panelCadastrarPedido_content']"

  #Cadastrar Pedido
  #Devido a forma que a página foi desenvolvida/implementada, esses elementos não ficarão na section.
  element :combobox_vendedor_items, "[id='formCadastrarPedido:vendedor_items']"
  element :combobox_sexo_items, "[id='formCadastrarPedido:sexo_1']"
  element :combobox_estado_civil_items, "[id='formCadastrarPedido:estadoCivil_5']"
  element :combobox_tipo_endereco_items, "[id='formCadastrarPedido:j_idt620_1']"
  element :combobox_tipo_contato_proprio, "[id='formCadastrarPedido:j_idt707_1']"
  element :button_avancar, "[id='formCadastrarPedido:j_idt770']"
  element :loading_icon, "[id='j_idt10_modal']"
  element :combobox_banco_items, "[id='formCadastrarPedido:banco_12']"
  element :input_numero_conta_corrente, "[id='formCadastrarPedido:numeroConta']"
  element :input_digito_conta_corrente, "[id='formCadastrarPedido:digitoConta']"
  element :combobox_dia_de_pagamento_items, "[id='formCadastrarPedido:diaPagamentoDebitoConta_2']"
  element :combobox_tipo_veiculo_items, "[id='formCadastrarPedido:j_idt862_1']"
  element :combobox_marca_veiculo_items, "[id='formCadastrarPedido:comboMarcaVeiculo_12']"
  element :combobox_modelo_veiculo_items, "[id='formCadastrarPedido:comboModeloVeiculo_12']" #PegarNovoElemento
  element :combobox_ano_fabricacao_items, "[id='formCadastrarPedido:comboAnoFabricacao_11']" #PegarNovoElemento
  element :combobox_ano_modelo_items, "[id='formCadastrarPedido:comboAnoModelo_1']"
  element :combobox_combustivel_items, "[id='formCadastrarPedido:comboCombustivel_2']"
  element :combobox_cor_items, "[id='formCadastrarPedido:comboCor_2']"
  element :combobox_categoria_veiculo_items, "[id='formCadastrarPedido:comboCategoria_1']"
  element :combobox_oferta_comercial_items, "[id='formCadastrarPedido:comboOfertaComercial_1']"
  element :combobox_promocao_items, "[id='formCadastrarPedido:comboPromocao_1']"

  def set_vendedor
    dados_iniciais.combobox_vendedor.click
    wait_until_combobox_vendedor_items_visible
    combobox_vendedor_items.click
  end

  #Consultar Pedido
  element :combobox_pesquisar_por, "[id='formPesquisa:tipoBusca_label']"
  element :combobox_pesquisar_por_items, "[id='formPesquisa:tipoBusca_3']"
  element :input_numero_pedido, "[id='formPesquisa:valorBusca']"
  element :button_pesquisar, "[id='formPesquisa:j_idt281']"
  element :button_detalhes_pedido, "[id='listaPedido:0:j_idt305']"
  element :form_detalhes_pedido, "[id='formDetalhePedido']"

  def pesquisar_por_numero_pedido
    combobox_pesquisar_por.click
    wait_until_combobox_pesquisar_por_items_visible
    combobox_pesquisar_por_items.click
    input_numero_pedido.click
    input_numero_pedido.set("13369457")
    button_pesquisar.click
  end

  def ver_detalhes_pedido
    wait_until_loading_icon_invisible
    button_detalhes_pedido.click
  end
end
