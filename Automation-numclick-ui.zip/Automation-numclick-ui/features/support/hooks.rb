require_relative 'helpers/screenshot.rb'

After do |scenario|
  Screenshot.print(scenario)
  Screenshot.delete_all_cookies
end

After do |scenario|
  DatasetBureau.new.bureau_dataset(scenario)
end