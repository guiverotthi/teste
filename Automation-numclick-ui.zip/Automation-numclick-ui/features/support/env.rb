require "capybara"
require "capybara/cucumber"
require "rspec"
require "selenium-webdriver"
require "site_prism"
require "yaml"
require "pry"

ENVIRONMENT_TYPE ||= ENV['ENVIRONMENT_TYPE']

CONFIG_UI = YAML.load_file "./features/support/config/#{ENVIRONMENT_TYPE}.yml"

HEADLESS = ENV['HEADLESS'] ? true : false

Capybara.register_driver :selenium do |app|
  options = Selenium::WebDriver::Chrome::Options.new(args: [])
    if HEADLESS
      options.add_argument('--headless')
      options.add_argument('--disable-gpu')
      options.add_argument('--window-size=1280,1024')
    end
  options.add_argument('--proxy-server=proxyservidores.cgmp-osa.com.br:3128')
  Capybara::Selenium::Driver.new(app, :browser => :chrome, options: options)
end

Capybara.default_driver = :selenium

Capybara.configure do |config|
  config.default_max_wait_time = 10
end

#Maximiza a tela ao iniciar o teste
Capybara.page.driver.browser.manage.window.maximize

today = Time.now.strftime('%Y_%m_%d').to_s
Capybara.save_path = File.expand_path("./features/results/#{today}")
