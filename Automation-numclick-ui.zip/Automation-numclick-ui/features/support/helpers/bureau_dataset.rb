require "csv"

class DatasetBureau

  def bureau_dataset(scenario)
    if (scenario.source_tag_names.last == "@adesao" || scenario.source_tag_names.last == "@inclusao_inativo" || scenario.source_tag_names.last == "@inclusao_ativo")
      case scenario.source_tag_names.last
        when "@adesao"
          dataset = "adesao"
        when "@inclusao_inativo"
          dataset = "inativo"
        when "@inclusao_ativo"
          dataset = "ativo"
      end
      csv = CSV.read("./features/support/massa/#{dataset}.csv")
      novo_csv = []
      csv.each_with_index do |row, index|
        if index > 0
          novo_csv << row
        end
      end
      CSV.open("./features/support/massa/#{dataset}.csv", "wb") do |csv|
        novo_csv.each do |row|
          csv << row
        end
      end
    else
      false
    end
  end
end
