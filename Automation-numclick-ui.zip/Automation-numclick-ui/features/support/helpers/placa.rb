class Placa

  #------- Gerador de Placa -------#

  def generator_placa
    "#{(0...3).map { ('A'..'Z').to_a[rand(26)] }.join}#{ 4.times.map{rand(4)}.join }"
  end
end
