class Screenshot
  def self.print(scenario)
    scenario.failed? ? result = "failed" : result = "passed"
    Capybara.current_session.save_screenshot("#{scenario.name.downcase!}_#{result}.png")
  end

  def self.delete_all_cookies
    Capybara.current_session.driver.browser.manage.delete_all_cookies
  end
end