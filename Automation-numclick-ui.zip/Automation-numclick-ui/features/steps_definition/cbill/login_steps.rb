Dado("que eu esteja na página de login") do
  @cbill_page = Cbill.new
  @cbill_page.load
end

Quando("eu submeto usuário e senha") do
  @cbill_page.login.submit
end

Então("valido usuário logado") do
  expect("Olá" + " " + CONFIG_UI['qa']['user_cbill']['usuario']).to eql (@cbill_page.msg_validacao_login.text)
end

Dado("que o usuário esteja logado no cbill") do
  steps %Q{
    Dado que eu esteja na página de login
    Quando eu submeto usuário e senha
    Então valido usuário logado
  }
end
