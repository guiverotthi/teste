Quando("pesquisar pelo documento principal") do
  @cbill_page.menu_cbill.menu_customer_manager.click
  browser = Capybara.current_session.driver.browser
  browser.switch_to.window(browser.window_handles.last)
  @cbill_page.customer_manager.combobox_conta.click
  @cbill_page.customer_manager.combobox_conta.click
  @cbill_page.customer_manager.combobox_conta_items.click
  binding.pry
  @cbill_page.customer_manager.input_documento.set(@cpf)
  @cbill_page.customer_manager.button_acesso_rapido.click
end

Quando("pesquisar pela placa cadastrada") do
  binding.pry
  @cbill_page.customer_manager.wait_until_menu_veiculos_visible
  @cbill_page.customer_manager.menu_veiculos.click
  @veiculos = @cbill_page.customer_manager.selecionar_placa
  @veiculos.each { |placas| placas.click if placas.text.include? @placa }
  @cbill_page.customer_manager.menu_identificadores.click
end

Então("validar o id ponto acesso") do
  @ids_ponto_acessos = @cbill_page.customer_manager.table_id_ponto_acesso
  @ids_ponto_acessos.each { |id_ponto_acesso| @table_id_validacao = id_ponto_acesso.text[0..9] if id_ponto_acesso.text include ("07091136791") } #@identificador }
  binding.pry
  expect(@identificador).to include (@table_id_validacao)
end
