Dado("tenha um usuário para efetuar pedido") do |dados|
  @cpf = eval(dados.rows_hash['cpf'])
  @identificador = eval(dados.rows_hash['identificador'])
  @placa = Placa.new.generator_placa
  puts @cpf
  puts @identificador
  puts @placa
  @numclick_page.wait_until_menu_realizar_venda_visible(wait: 3)
  @numclick_page.wait_until_loading_spinner_invisible
  @numclick_page.menu_realizar_venda.click
end

Quando("inserir os dados do cliente") do
  @numclick_page.dados_cliente.preencher_cliente(@cpf)
  @numclick_page.wait_until_button_avancar_visible
  @numclick_page.button_avancar.click
end

Quando("preencher os dados de endereço") do
  @numclick_page.dados_endereco.preencher_endereco
  @numclick_page.button_avancar.click
end

Quando("selecionar a forma de pagamento {string}") do |tipo_pagamento|
  if tipo_pagamento == "cartao_credito_pre"
    @numclick_page.dados_pagamento.preencher_cartao_credito
  else 
    @numclick_page.dados_pagamento.preencher_debito_em_conta(tipo_pagamento)
  end
  @numclick_page.wait_until_button_avancar_visible
  @numclick_page.button_avancar.click
end

Quando("o tipo de veiculo {string} com a {string} conforme o {string}") do |tipo_veiculo, oferta, tipo_pagamento|
   tipo_veiculo.eql?("passeio") ? @numclick_page.dados_veiculo.preecher_veiculo_passeio(@placa) : @numclick_page.dados_veiculo.preecher_veiculo_utilitario(@placa)
    if oferta == "TRIO"
      @numclick_page.dados_veiculo.oferta_trio(tipo_pagamento)
    else
      @numclick_page.dados_veiculo.oferta_pos(tipo_pagamento)
    end
end

Quando("tipo de entrega {string}") do |tipo_entrega|
  @tipo_entrega = tipo_entrega
  case tipo_entrega
  when "nesta_loja"
    @numclick_page.dados_veiculo.radiobutton_retirar_nesta_loja.click
  when "qualquer_loja"
    @numclick_page.dados_veiculo.radiobutton_retirar_qualquer_loja.click
  when "delivery"
    @numclick_page.dados_veiculo.radiobutton_delivery.click
    @numclick_page.button_avancar.click
    @numclick_page.dados_delivery.preecher_endereco_delivery
  end  
  @numclick_page.button_avancar.click
end

Então("valido o pedido na tela de resumo e envio para analise") do
  @validar_cpf = ("#{@cpf[0..2]}.#{@cpf[3..5]}.#{@cpf[6..8]}-#{@cpf[9..10]}")
  expect(@numclick_page.dados_resumo.text).to include @validar_cpf
  expect(@numclick_page.dados_resumo.text).to include @placa
  @numclick_page.dados_resumo.button_enviar_para_analise.click
  @numclick_page.wait_until_loading_spinner_invisible(wait: 20)
  @numclick_page.dados_resumo.wait_until_msg_pedido_aprovado_visible(wait: 180)
  @numero_pedido = @numclick_page.dados_resumo.msg_pedido_aprovado.text[9..16]
  expect(@numclick_page.dados_resumo.msg_pedido_aprovado.text).to eql ("O Pedido #{@numero_pedido} foi Aprovado com sucesso!")
  @numclick_page.dados_resumo.button_ok.click
end

Então("valido a atribuição do pedido") do
  if @tipo_entrega == ("nesta_loja" || "qualquer_loja")
    @numclick_page.dados_atribuicao.input_identificador.set(@identificador)
    @numclick_page.dados_atribuicao.button_atribuir.click
    @numclick_page.wait_until_loading_spinner_invisible
    expect(@numclick_page.dados_atribuicao.msg_pedido_atribuido.text).to eql ("Identificador atribuido com sucesso!")
    binding.pry
  else
    step 'que o usuário esteja logado na logistica'
    step 'efetuar a busca pelo numero do pedido'
  end
  puts @numero_pedido
  @numclick_page.wait_until_loading_spinner_invisible(wait: 30)
end

Então("valido o pedido no cbill") do  
  step 'que o usuário esteja logado no cbill'
  step 'pesquisar pelo documento principal'
  step 'pesquisar pela placa cadastrada'
  step 'validar o id ponto acesso'
end
