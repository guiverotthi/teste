Dado("que estou na tela de login do numclick") do
  @numclick_page = NumClick.new
  @numclick_page.load
  #------- autenticação na fleetcor -------#
  # @numclick_page.fleetcor_submit  
end

Quando("realizar o login com usuário válido") do
  @numclick_page.button_login.click
  @numclick_page.aws_submit
end

Então("o login é realizado com sucesso") do
  expect(@numclick_page.msg_validacao_login.text).to eql ("Home")
end

Dado("que o usuário esteja logado no numclick") do
  steps %Q{
    Dado que estou na tela de login do numclick
    Quando realizar o login com usuário válido
    Então o login é realizado com sucesso
  }
end
