Quando("efetuar a busca e atribuicao pelo numero do pedido") do
  @logistica_page.wait_until_menu_operacoes_visible
  @logistica_page.menu_operacoes.hover
  @logistica_page.wait_until_item_menu_atribuir_delivery_visible
  @logistica_page.item_menu_atribuir_delivery.click
  @numero_pedido = 13449522 #chumbado, remover no fluxo total
  @logistica_page.pesquisar_pedidos.input_numero_pedido.click
  @logistica_page.pesquisar_pedidos.input_numero_pedido.set(@numero_pedido)
  @logistica_page.pesquisar_pedidos.input_numero_pedido.set("")
  @logistica_page.pesquisar_pedidos.input_numero_pedido.set(@numero_pedido)
  @logistica_page.pesquisar_pedidos.button_pesquisar.click
  @logistica_page.wait_until_loading_spinner_invisible
  @logistica_page.pesquisar_pedidos.span_pedido.click
  @logistica_page.wait_until_loading_spinner_invisible
  @logistica_page.pesquisar_pedidos.button_avancar.click
  @logistica_page.wait_until_loading_spinner_invisible(wait: 30)
  @logistica_page.pesquisar_pedidos.input_identificador.set("07147500590")  #(@identificador)
  @logistica_page.pesquisar_pedidos.button_avancar_atribuir.click
  @logistica_page.wait_until_loading_spinner_invisible(wait: 30)
  binding.pry
  # expect(@logistica_page.pesquisar_pedidos.validar_placa.text).to include ("POI7855" && "07166567900") #(@placa && @identificador)
  expect(@logistica_page.pesquisar_pedidos.validar_placa.text).to eql("TRE1314") #(@placa)
  expect(@logistica_page.pesquisar_pedidos.validar_identificador.text).to eql("07147500590") #(@identificador)
  @logistica_page.pesquisar_pedidos.button_finalizar.click
  @logistica_page.wait_until_loading_spinner_invisible(wait: 30)
end

Então("valido pedido atribuido na tela de resumo") do
  expect(@logistica_page.pesquisar_pedidos.msg_validacao_sucesso).to eql ("Identificador atribuído com sucesso")
  # @logistica_page.pesquisar_pedidos.has_msg_validacao_sucesso?
end
