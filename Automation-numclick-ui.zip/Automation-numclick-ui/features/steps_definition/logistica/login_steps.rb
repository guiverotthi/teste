Dado("que eu esteja na página de login da logistica") do
  @logistica_page = Logistica.new
  @logistica_page.load
end

Quando("eu submeto nome e password") do
  @logistica_page.login.login_logistica
end

Então("eu valido usuário logado") do
  @usuario = CONFIG_UI['qa']['user_logistica']['usuario']
  expect(@usuario).to eql (@logistica_page.validacao_login).text
  expect(@logistica_page.msg_validacao_login.text).to eql ("Bem vindo ao Logistica.")
end

Dado("que o usuário esteja logado na logistica") do
  steps %Q{
    Dado que eu esteja na página de login da logistica
    Quando eu submeto nome e password
    Então eu valido usuário logado
  }
end