require_relative "sections_cbill.rb"

class Cbill < SitePrism::Page

  set_url CONFIG_UI['qa']['cbill_url']

  section :login, LoginCbill,                 '#login'
  section :menu_cbill, MenuCbill,             '#launcher'
  section :customer_manager, CustomerManager, '#index-header'
  
  #Devido a forma que a página foi desenvolvida/implementada, esses elementos não ficarão na section.
  element :msg_validacao_login, :xpath, '//div[@id="welcome"]/div/h3'
end
