require 'site_prism'

class LoginCbill < SitePrism::Section
  element :input_username, '[id="j_username"]'
  element :input_password, '[id="j_password"]'
  element :button_entrar,  'input[type="submit"]'

  def submit
    # wait_until_button_entrar_visible
    input_username.set CONFIG_UI['qa']['user_cbill']['usuario']
    input_password.set CONFIG_UI['qa']['user_cbill']['senha']
    button_entrar.click
  end
end

# devido ao clicar no menu abrir a página em uma nova aba, esta classe ainda não esta sendo utilizada
class MenuCbill < SitePrism::Section
  element :menu_customer_manager, '[class="customer_manager front"]'
end

class CustomerManager < SitePrism::Section
  element  :combobox_conta, :xpath,       '//select[contains(@name, "fastAccessForm_j_idt42")]'
  element  :combobox_conta_items,         '[value="DOCUMENT_NUMBER"]'
  element  :input_documento,              '[id="fastAccessForm_j_idt44"]'
  element  :button_acesso_rapido, :xpath, '//span[contains(text(), "Acesso rápido")]'
  element  :menu_veiculos, :xpath,        '//span[contains(text(), "Veículos")]'
  element  :input_placa, :xpath,          '//input[@id="vehicleData_j_idt804_filter"]'
  elements :selecionar_placa, :xpath,     '//tbody[@id="vehicleData_data"]/tr'
  element  :menu_identificadores, :xpath, '//a[contains(text(), "Identificadores associados")]'
  elements :table_id_ponto_acesso, :xpath, '//tbody[@id="vehicleTabView_tableAccessPointIdentifications_data"]'
end