require 'site_prism'

class DadosCliente < SitePrism::Section
  element :input_cpf,     'input[name="input-cpf"]'
  element :input_name,    'input[name="input-nome"]'
  element :input_email,   'input[name="input-email"]'
  element :input_ddd,     'input[name="input-ddd"]'
  element :input_celular, 'input[name="input-celular"]'
     
  def preencher_cliente(cpf)
    input_cpf.set(cpf).send_keys(:tab)
    NumClick.new.wait_until_button_avancar_visible(wait: 30) # Devido ao loading
    # input_email.value.eql?("") ? input_email.set("automacao@semparar.net") : false
    # input_ddd.value.eql?("") ? input_ddd.set(11) : false
    # input_celular.value.eql?("") ? input_celular.set(977889944) : false
  end
end

class DadosPagamento < SitePrism::Section
  #------- cartão de crédito -------#
  element :radiobutton_cartao_de_credito,   '#radio-cartao-credito'
  element :input_numero_do_cartao,          'input[name="input-numero-cartao"]'
  element :input_nome_impresso,             'input[name="input-nome-impresso"]'
  element :input_data_validade,             '#input-validade'
  element :button_data_ok, :xpath,          '//button[contains(text(), "OK")]'
  #------- débito em conta pré/pós -------#
  element :radiobutton_debito_em_conta_pos, '#radio-debito-conta-pos'
  element :radiobutton_debito_em_conta_pre, '#radio-debito-conta-pre'
  element :radiobutton_conta_propria,       '#radio-conta-propria'
  element :radiobutton_conta_outra_pessoa,  '#radio-conta-outra-pessoa'
  element :menu_select_banco,               '#select-banco'
  # elements :menu_select_banco_items, :xpath, '//ion-list/ion-radio-group/ion-item'
  # element :menu_select_banco_item, :xpath,   '//ion-list/ion-radio-group/ion-item[1]'
  element :input_agencia,                   'input[name="input-agencia"]'
  element :input_conta,                     'input[name="input-conta"]'
  element :input_digito_conta,              'input[name="input-digito-conta"]'
  element :menu_select_dia_pagamento,       '[id="select-dia-pagamento"]'
  # elements :menu_select_dia_pagamento_items, :xpath, '//div/div/ion-select-popover/ion-list/ion-radio-group/ion-item'
  element :input_cpf_titular_conta,         'input[name="input-cpf-titular-conta"]'
  element :input_ddd_titular_conta,         'input[name="input-ddd-titular-conta"]'
  element :input_cel_titular_conta,         'input[name="input-celular-titular-conta"]'

  def preencher_cartao_credito
    radiobutton_cartao_de_credito.click
    input_numero_do_cartao.click
    numero = (5554088020648758)
    input_numero_do_cartao.set(numero)
    input_numero_do_cartao.set(numero)
    input_data_validade.click
    wait_until_button_data_ok_visible
    button_data_ok.click
  end

  def preencher_debito_em_conta(tipo_pagamento)
    tipo_pagamento.eql?("debito_conta_propria_pos") || tipo_pagamento.eql?("debito_conta_terceiro_pos") ? radiobutton_debito_em_conta_pos.click : radiobutton_debito_em_conta_pre.click
    if tipo_pagamento == ("debito_conta_propria_pos") || tipo_pagamento == ("debito_conta_propria_pre")
      radiobutton_conta_propria.click
    else
      radiobutton_conta_outra_pessoa.click
      input_cpf_titular_conta.set(16385709817)
      input_ddd_titular_conta.set(11)
      input_cel_titular_conta.set(977225588)
    end
    wait_until_menu_select_banco_visible
    menu_select_banco.click
    NumClick.new.menu_select_all_items.each { |banco| if banco.text.include? "237-BANCO BRADESCO S.A."; banco.click; break; end }
    input_agencia.set(5641)
    input_conta.set(1518992)
    input_digito_conta.set(4)
    if tipo_pagamento == ("debito_conta_propria_pos" || "debito_conta_terceiro_pos")
      menu_select_dia_pagamento.click
      NumClick.new.menu_select_all_items.each { |dia| if dia.text.include? "15"; dia.click; break; end }
    else
      false
    end
  end
end

class DadosEndereco < SitePrism::Section
  element :input_cep,          'input[name="input-cep-cliente"]'
  element :input_logradouro,   'input[name="input-logradouro-cliente"]'
  element :input_numero,       'input[name="input-numero-cliente"]'
  element :input_complemento,  'input[name="input-complemento-cliente"]'
  element :input_bairro,       'input[name="input-bairro-cliente"]'
  element :input_cidade,       'input[name="input-cidade-cliente"]'
  element :menu_select_estado, '#select-estado-cliente'
  # elements :menu_select_estado_items,:xpath, '//div/div/ion-select-popover/ion-list/ion-radio-group/ion-item' #melhorar xpath
  
  def preencher_endereco
    sleep(2) #devido ao load da pagina
    input_cep.value.eql?("") ? input_cep.set(06020010).send_keys(:tab) : false
    input_logradouro.value.eql?("") ? input_logradouro.set("Avenida Dos Autonomistas") : false
    input_numero.value.eql?("") ? input_numero.set(896) : false
    input_complemento.value.eql?("") ? input_complemento.set("Predio A") : false
    input_bairro.value.eql?("") ? input_bairro.set("Vila Yara") : false
    input_cidade.value.eql?("") ? input_cidade.set("Osasco") : false
    if menu_select_estado.value == ("")
      menu_select_estado.click
      NumClick.new.menu_select_all_items.each { |estado| if estado.text.include? "SP"; estado.click; break; end }
    else
      false
    end
  end
end

class DadosVeiculo < SitePrism::Section
  element :input_placa,                        'input[name="input-placa"]'
  element :radiobutton_veiculo_passeio,        '#radio-tipo-passeio'
  element :radiobutton_veiculo_utilitario,     '#radio-tipo-utilitario'
  element :menu_select_marca,                  '#select-marca'
  elements :menu_select_marca_items, :xpath,   '//div[@class="action-sheet-group sc-ion-action-sheet-md"]/button'
  element :menu_select_modelo,                 '#select-modelo'
  elements :menu_select_modelo_items, :xpath,  '//div[@class="action-sheet-group sc-ion-action-sheet-md"]/button'
  element :menu_select_ano_fabricacao,         '#select-ano-fabricacao'
  elements :menu_ano_fabricacao_items, :xpath, '//div[@class="action-sheet-group sc-ion-action-sheet-md"]/button'
  
  element :menu_select_oferta,                 '#select-oferta'
  elements :menu_select_oferta_items, :xpath,  '//div[@class="action-sheet-group sc-ion-action-sheet-md"]/button'
  element :menu_select_promocao,               '#select-promocao'
  # elements :menu_select_promocao_items, :xpath, '//div/div/ion-select-popover/ion-list/ion-radio-group/ion-item'
  element :menu_select_disparo,               '#select-disparo'
  # elements :menu_select_disparo_items,         '//div/div/ion-select-popover/ion-list/ion-radio-group/ion-item'
  element :radiobutton_retirar_qualquer_loja, '#radio-entrega-retira-qualquer-loja'
  element :radiobutton_retirar_nesta_loja,    '#radio-entrega-retira-nessa-loja'
  element :radiobutton_delivery,              '#radio-entrega-delivery'

  def preecher_veiculo_passeio(placa)
    input_placa.set(placa).send_keys(:tab)
    NumClick.new.wait_until_loading_spinner_invisible(wait: 40)
    wait_until_radiobutton_veiculo_passeio_visible
    radiobutton_veiculo_passeio.click
    menu_select_marca.click
    wait_until_menu_select_marca_items_visible
    menu_select_marca_items.each { |marca| if marca.text.include? "AUDI"; marca.click; break; end }
    wait_until_menu_select_marca_items_invisible
    NumClick.new.wait_until_loading_spinner_invisible
    # wait_until_menu_select_modelo_visible
    menu_select_modelo.click
    wait_until_menu_select_modelo_items_visible
    menu_select_modelo_items.each { |modelo| if modelo.text.include? "A5"; modelo.click; break; end }
    wait_until_menu_select_modelo_items_invisible
    NumClick.new.wait_until_loading_spinner_invisible
    menu_select_ano_fabricacao.click
    NumClick.new.wait_until_menu_select_all_items_visible
    NumClick.new.menu_select_all_items.each { |ano| if ano.text.include? "2013"; ano.click; break; end }
  end

  def preecher_veiculo_utilitario(placa)
    input_placa.set(placa).send_keys(:tab)
    NumClick.new.wait_until_loading_spinner_visible
    NumClick.new.wait_until_loading_spinner_invisible(wait: 40)
    radiobutton_veiculo_utilitario.click
    menu_select_marca.click
    wait_until_menu_select_marca_items_visible
    menu_select_marca_items.each { |marca| if marca.text.include? "TOYOTA"; marca.click; break; end }
    NumClick.new.wait_until_loading_spinner_invisible
    wait_until_menu_select_modelo_visible
    menu_select_modelo.click
    wait_until_menu_select_modelo_items_visible
    menu_select_modelo_items.each { |modelo| if modelo.text.include? "HILUX"; modelo.click; break; end }
    wait_until_menu_select_modelo_items_invisible
    menu_select_ano_fabricacao.click
    NumClick.new.menu_select_all_items.each { |ano| if ano.text.include? "2017"; ano.click; break; end }
  end

  def oferta_trio(tipo_pagamento)
    NumClick.new.wait_until_loading_spinner_invisible(wait:30) #devido ao loading eterno...
    menu_select_oferta.click
    if tipo_pagamento.eql?("debito_conta_propria_pos") || tipo_pagamento.eql?("debito_conta_terceiro_pos") || tipo_pagamento.eql?("cartao_credito_pre")
      menu_select_oferta_items.each { |oferta| if oferta.text.include? "EM TODO LUGAR - CARTÃO"; oferta.click; break; end }
      wait_until_menu_select_oferta_items_invisible
    else
      NumClick.new.menu_select_all_items.each { |oferta| if oferta.text.include? "PRÉ-PAGO PAULISTA"; oferta.click; break; end }
      menu_select_disparo.click
      NumClick.new.menu_select_all_items.each { |disparo| if disparo.text.include? "150"; disparo.click; break; end }
    end
    NumClick.new.wait_until_loading_spinner_invisible(wait: 20)
  end

  def oferta_pos(tipo_pagamento)
    NumClick.new.wait_until_loading_spinner_invisible(wait:30) #devido ao loading eterno...
    menu_select_oferta.click
    if tipo_pagamento.eql?("debito_conta_propria_pos") || tipo_pagamento.eql?("debito_conta_terceiro_pos") || tipo_pagamento.eql?("cartao_credito_pre")
      menu_select_oferta_items.each { |oferta| if oferta.text.include? "ADESÃO ZERO II"; oferta.click; break; end }
      NumClick.new.wait_until_loading_spinner_invisible
    else
      menu_select_oferta_items.each { |oferta| if oferta.text.include? "PRÉ-PAGO PAULISTA"; oferta.click; break; end }
      menu_select_disparo.click
      NumClick.new.menu_select_all_items.each { |disparo| if disparo.text.include? "150"; disparo.click; break; end }
    end
  end
end

class DadosDelivery < SitePrism::Section
  element :input_cep_delivery,          'input[name="input-cep"]'
  element :input_logradouro_delivery,   'input[name="input-logradouro"]'
  element :input_numero_delivery,       'input[name="input-numero"]'
  element :input_complemento_delivery,  'input[name="input-complemento"]'
  element :input_bairro_delivery,       'input[name="input-bairro"]'
  element :input_cidade_delivery,       'input[name="input-cidade"]'
  element :menu_select_estado_delivery, '#select-estado'
  
  def preecher_endereco_delivery
    wait_until_input_cep_delivery_visible
    # input_cep_delivery.set(06020010).send_keys(:tab)
    input_cep_delivery.value.eql?("") ? input_cep_delivery.set("06020010") : false
    input_logradouro_delivery.value.eql?("") ? input_logradouro_delivery.set("Avenida Dos Autonomistas") : false
    input_numero_delivery.value.eql?("") ? input_numero_delivery.set(896) : false
    input_complemento_delivery.value.eql?("") ? input_complemento_delivery.set("Predio A") : false
    input_bairro_delivery.value.eql?("") ? input_bairro_delivery.set("Vila Yara") : false
    input_cidade_delivery.value.eql?("") ? input_cidade_delivery.set("Osasco") : false
    if menu_select_estado_delivery.value == ("")
      menu_select_estado_delivery.click
      NumClick.new.menu_select_all_items.each { |estado| if estado.text.include? "SP"; estado.click; break; end }
    else
      false
    end
  end
end

class DadosResumo < SitePrism::Section
  elements :div_items_resumo, :xpath,           '//ion-slide/ion-list/div'
  element  :button_enviar_para_analise, :xpath, '//ion-button[contains(text(), "Analisar")]'
  # element  :barra_processamento, :xpath,        '//ion-progress-bar[@ng-reflect-value="1.00"]'
  element  :barra_processamento, :xpath,        '//ion-progress-bar'
  element  :msg_pedido_aprovado, :xpath,        '//div[@class="alert-message sc-ion-alert-md"]'
  element  :button_ok, :xpath,                  '//*[contains(text(), "OK")]' 
end

class DadosAtribuicao < SitePrism::Section
  element :input_identificador,          'input[name="input-identificador"]'
  element :button_atribuir, :xpath,      '//ion-button[contains(text(), " Atribuir ")]'
  element :msg_pedido_atribuido, :xpath, '//div[@class="alert-message sc-ion-alert-md"]'
end
