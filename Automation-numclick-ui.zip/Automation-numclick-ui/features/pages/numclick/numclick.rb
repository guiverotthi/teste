require_relative "sections_numclick.rb"

class NumClick < SitePrism::Page

  set_url CONFIG_UI['qa']['numclick_url']

  section :dados_cliente, DadosCliente,       '#list-itens-clientes'
  section :dados_pagamento, DadosPagamento,   '#list-itens-pagamento'
  section :dados_endereco, DadosEndereco,     '#list-itens-endereco-cliente'
  section :dados_veiculo, DadosVeiculo,       '#list-itens-veiculo'
  section :dados_delivery, DadosDelivery,     '#list-itens-endereco-delivery'
  section :dados_resumo, DadosResumo,         '#list-itens-resumo'
  section :dados_atribuicao, DadosAtribuicao, '#list-itens-atribuicao'

  # ------- FLEETCOR ------- #
  element :input_username,                 '#okta-signin-username'
  element :input_password,                 '#okta-signin-password'
  element :button_submit,                  '#okta-signin-submit'
  
  # ------- LOGIN AMAZON ------- #
  element :input_username_aws,             '[id="userNameInput"]'
  element :input_password_aws,             '[id="passwordInput"]'
  element :button_submit_aws,              '[id="submitButton"]'
  element :msg_validacao_login, :xpath,    '//ion-title[contains(text(), "Home")]'
  
  # ------- NumClick ------- #
  element :button_login,                   '#button-login'
  element :menu_realizar_venda,            '[name="cart"]'
  element :button_avancar, :xpath,         '//ion-button[contains(text(), " Avançar ")]' #botão avançar que ira servir para todas as sections!
  element :loading_spinner, :xpath,        '//ion-loading[@class="sc-ion-loading-md-h sc-ion-loading-md-s loading-translucent hydrated"]'
  #devido a forma da pagina, os elemenstos das listas estão fora das sections
  elements :menu_select_all_items, :xpath, '//ion-list/ion-radio-group/ion-item'
  element  :button_ok, :xpath,             '//*[contains(text(), "OK")]'
  element  :numero_pedido, :xpath,         '//div[@class="alert-message sc-ion-alert-md"]'

  # def fleetcor_submit
  #   input_username.set CONFIG_UI['qa']['user_fleetcor']['usuario']
  #   input_password.set CONFIG_UI['qa']['user_fleetcor']['senha']
  #   button_submit.click
  #   binding.pry
  #   wait_until_button_login_visible(wait: 30)
  # end

  def aws_submit
    input_username_aws.set CONFIG_UI['qa']['user_numclick']['name']
    input_password_aws.set CONFIG_UI['qa']['user_numclick']['password']
    button_submit_aws.click
  end
end
