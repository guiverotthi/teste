require_relative "sections_logistica.rb"

class Logistica < SitePrism::Page
  
  set_url CONFIG_UI['qa']['logistica_url']

  section :login, LoginLogistica,               '#formLogin'
  section :pesquisar_pedidos, PesquisarPedidos, 'form[id="j_idt57"]'

  element :msg_validacao_login, :xpath,         '//h2[contains(text(), "Bem vindo ao Logistica.")]'
  element :validacao_login,                     'li > table > tbody > tr > td:nth-child(4)'
  element :menu_operacoes, :xpath,              '//span[contains(text(), "Operações")]'
  element :item_menu_atribuir_delivery, :xpath, '//span[contains(text(), "Atribuir Identificador Delivery")]'

  element :loading_spinner,                     'img[id="j_idt13"]'
end
