require 'site_prism'

class LoginLogistica < SitePrism::Section
  element :input_name,           'input[id="formLogin:userName"]'
  element :input_password,       'input[id="formLogin:password"]'
  element :button_login, :xpath, '//span[contains(text(), "Login")]'

  def login_logistica
    input_name.set(CONFIG_UI['qa']['user_logistica']['usuario'])
    input_password.set(CONFIG_UI['qa']['user_logistica']['senha'])
    button_login.click
  end
end

class PesquisarPedidos < SitePrism::Section
  element :input_numero_pedido,           '#numeroPedido'
  element :button_pesquisar,              '#btnPesquisar'
  element :span_pedido, :xpath,           '//tbody[@id="listaPedido_data"]/tr/td/div/div/span'
  element :button_avancar,                '#avancarBtn'

  element :input_identificador, :xpath,   '//tbody[@id="veiculosTable_data"]/tr/td[8]/input'
  element :validar_placa, :xpath,         '//tbody[@class="ui-datatable-data ui-widget-content"]/tr/td[2]'
  element :validar_identificador, :xpath, '//tbody[@class="ui-datatable-data ui-widget-content"]/tr/td[8]'

  element :button_avancar_atribuir,       '#btnAvancar'
  element :button_finalizar,              '#finalizarBtn'
  element :msg_validacao_sucesso, :xpath, '//span[contains(text(), "Identificador atribuído com sucesso")]'
end
